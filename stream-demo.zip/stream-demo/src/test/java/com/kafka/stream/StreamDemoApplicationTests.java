package com.kafka.stream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
