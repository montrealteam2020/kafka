package com.bank.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
