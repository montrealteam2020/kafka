package com.kafka.schema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaSchemaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaSchemaDemoApplication.class, args);
	}

}
